import os
import logging
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

from app.config import settings
from app.api import auth, waste, energy, recommendations, impact, aws_status

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("ecovision")

app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description="EcoVision AI – Smart Waste & Energy Optimization Platform"
)

# Enable CORS for frontend flexibility
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include API Routers
app.include_router(auth.router)
app.include_router(waste.router)
app.include_router(energy.router)
app.include_router(recommendations.router)
app.include_router(impact.router)
app.include_router(aws_status.router)

# Mount Static directory
static_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "static")
os.makedirs(os.path.join(static_dir, "uploads"), exist_ok=True)
app.mount("/static", StaticFiles(directory=static_dir), name="static")

@app.get("/")
def serve_spa():
    """Serve SPA index.html."""
    index_path = os.path.join(static_dir, "index.html")
    if os.path.exists(index_path):
        return FileResponse(index_path)
    return {"message": "EcoVision AI API is running. Index file not found."}

@app.get("/health")
def health_check():
    return {
        "status": "healthy",
        "app": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "aws_credentials_present": settings.has_aws_credentials
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
