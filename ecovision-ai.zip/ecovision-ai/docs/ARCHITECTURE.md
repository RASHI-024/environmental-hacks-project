# EcoVision AI System & AWS Architecture Documentation

## 1. System Overview
EcoVision AI is a full-stack, cloud-ready sustainability platform engineered to optimize waste management and energy efficiency across institutional environments (Colleges, Hostels, Offices, Communities).

```
                      +---------------------------------------+
                      |          React 18 SPA Frontend        |
                      |  (Dashboard, AI Scanner, Analytics)   |
                      +-------------------+-------------------+
                                          |
                                          | REST API (HTTP / JSON)
                                          v
                      +-------------------+-------------------+
                      |          FastAPI Application          |
                      |  (Auth, Waste, Energy, Recs, Impact)  |
                      +---------+-------------------+---------+
                                |                   |
               +----------------+                   +----------------+
               |                                                     |
               v                                                     v
+--------------+---------------+                     +---------------+---------------+
|       AWS Services Layer      |                     |    Local Storage Fallback     |
|                              |                     |            Layer              |
|  - Amazon S3 (Waste Images)  |                     |  - Local Media (/static/)     |
|  - Amazon DynamoDB (Tables)  |                     |  - JSON Store (data/db.json)  |
|  - AWS Lambda (Serverless)   |                     |  - Computer Vision Heuristics |
|  - Amazon API Gateway        |                     +-------------------------------+
+------------------------------+
```

## 2. AWS Service Integration
EcoVision AI meaningfully integrates AWS services to power scalable cloud operations:

1. **Amazon S3 (`ecovision-waste-images`)**:
   - Stores user-uploaded waste inspection photographs and computer vision bounding box output renders.
   - Provides pre-signed URLs for secure, fast media delivery.

2. **Amazon DynamoDB (NoSQL Data Store)**:
   - `EcoVision_Users`: User accounts, organization roles, and credentials.
   - `EcoVision_WasteLogs`: Daily/monthly waste records, category classifications, quantities (kg), and disposal methods.
   - `EcoVision_EnergyLogs`: Utility records (electricity kWh, water liters, operating hours, anomaly flags).
   - `EcoVision_Recommendations`: AI-generated prioritized sustainability cards.

3. **AWS Lambda & Amazon API Gateway**:
   - Serverless ASGI application handler (`app.lambda_handler.handler`) via `mangum`.
   - Scales automatically with zero idle server cost.

4. **AWS Amplify**:
   - Configured for single-command automated CI/CD frontend hosting.

## 3. Dual-Mode Architecture & Judging Fallback
To ensure 100% presentation reliability during hackathon judging:
- The system automatically detects whether valid AWS credentials exist in `.env`.
- If credentials are present, all API transactions execute against AWS DynamoDB and Amazon S3 in real-time.
- If credentials are omitted, the system transparently proxies calls to a local JSON file storage engine seeded with realistic campus/office data, keeping all features, charts, AI analysis, and scorecards fully operational!
