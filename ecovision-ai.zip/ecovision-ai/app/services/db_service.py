import os
import json
import logging
from typing import List, Dict, Any, Optional
from app.config import settings
from app.seed_data import ORGANIZATIONS, get_demo_waste_logs, get_demo_energy_logs, get_demo_recommendations

logger = logging.getLogger("ecovision.db")

class DatabaseService:
    def __init__(self):
        self.use_dynamodb = False
        self.dynamodb = None
        self.local_db_file = os.path.join(settings.LOCAL_DATA_DIR, "ecovision_db.json")
        self._init_db()

    def _init_db(self):
        # 1. Try AWS DynamoDB connection if credentials are configured
        if settings.has_aws_credentials:
            try:
                import boto3
                self.dynamodb = boto3.resource(
                    'dynamodb',
                    region_name=settings.AWS_REGION,
                    aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
                    aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY
                )
                # Quick health check call
                self.dynamodb.tables.all()
                self.use_dynamodb = True
                logger.info("Connected to AWS DynamoDB successfully.")
                return
            except Exception as e:
                logger.warning(f"AWS DynamoDB connection failed: {e}. Falling back to local storage.")
                self.use_dynamodb = False

        # 2. Local database fallback
        os.makedirs(settings.LOCAL_DATA_DIR, exist_ok=True)
        if not os.path.exists(self.local_db_file):
            self._seed_local_db()

    def _seed_local_db(self):
        """Seed initial local database with rich realistic data."""
        data = {
            "users": [
                {
                    "id": "usr_demo",
                    "email": "sustainability@campus.edu",
                    "full_name": "Dr. Aris Vance",
                    "organization_id": "org_college",
                    "organization_name": "Green Valley University Campus",
                    "organization_type": "College",
                    "role": "Sustainability Director"
                }
            ],
            "organizations": ORGANIZATIONS,
            "waste_logs": get_demo_waste_logs("org_college"),
            "energy_logs": get_demo_energy_logs("org_college"),
            "recommendations": get_demo_recommendations("org_college")
        }
        with open(self.local_db_file, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        logger.info("Local database seeded successfully.")

    def _read_local_db(self) -> Dict[str, Any]:
        if not os.path.exists(self.local_db_file):
            self._seed_local_db()
        try:
            with open(self.local_db_file, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            self._seed_local_db()
            with open(self.local_db_file, "r", encoding="utf-8") as f:
                return json.load(f)

    def _write_local_db(self, data: Dict[str, Any]):
        with open(self.local_db_file, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    # --- User Operations ---
    def get_user_by_email(self, email: str) -> Optional[Dict[str, Any]]:
        if self.use_dynamodb:
            table = self.dynamodb.Table(settings.DYNAMODB_USERS_TABLE)
            res = table.get_item(Key={'email': email})
            return res.get('Item')
        else:
            db = self._read_local_db()
            for u in db.get("users", []):
                if u.get("email") == email:
                    return u
            return None

    def create_user(self, user_data: Dict[str, Any]) -> Dict[str, Any]:
        if self.use_dynamodb:
            table = self.dynamodb.Table(settings.DYNAMODB_USERS_TABLE)
            table.put_item(Item=user_data)
        else:
            db = self._read_local_db()
            db.setdefault("users", []).append(user_data)
            self._write_local_db(db)
        return user_data

    # --- Organization Operations ---
    def get_organizations(self) -> List[Dict[str, Any]]:
        db = self._read_local_db()
        return db.get("organizations", ORGANIZATIONS)

    def get_organization(self, org_id: str) -> Dict[str, Any]:
        orgs = self.get_organizations()
        for o in orgs:
            if o.get("id") == org_id:
                return o
        return ORGANIZATIONS[0]

    # --- Waste Log Operations ---
    def add_waste_log(self, log_entry: Dict[str, Any]) -> Dict[str, Any]:
        if self.use_dynamodb:
            table = self.dynamodb.Table(settings.DYNAMODB_WASTE_TABLE)
            table.put_item(Item=log_entry)
        else:
            db = self._read_local_db()
            db.setdefault("waste_logs", []).insert(0, log_entry)
            self._write_local_db(db)
        return log_entry

    def get_waste_logs(self, org_id: str) -> List[Dict[str, Any]]:
        if self.use_dynamodb:
            table = self.dynamodb.Table(settings.DYNAMODB_WASTE_TABLE)
            # Scan / Query DynamoDB
            response = table.scan()
            items = response.get('Items', [])
            return [i for i in items if i.get('org_id') == org_id]
        else:
            db = self._read_local_db()
            logs = db.get("waste_logs", [])
            org_logs = [l for l in logs if l.get("org_id") == org_id]
            if not org_logs:
                org_logs = get_demo_waste_logs(org_id)
            return org_logs

    # --- Energy Log Operations ---
    def add_energy_log(self, energy_entry: Dict[str, Any]) -> Dict[str, Any]:
        if self.use_dynamodb:
            table = self.dynamodb.Table(settings.DYNAMODB_ENERGY_TABLE)
            table.put_item(Item=energy_entry)
        else:
            db = self._read_local_db()
            db.setdefault("energy_logs", []).insert(0, energy_entry)
            self._write_local_db(db)
        return energy_entry

    def get_energy_logs(self, org_id: str) -> List[Dict[str, Any]]:
        if self.use_dynamodb:
            table = self.dynamodb.Table(settings.DYNAMODB_ENERGY_TABLE)
            response = table.scan()
            items = response.get('Items', [])
            return [i for i in items if i.get('org_id') == org_id]
        else:
            db = self._read_local_db()
            logs = db.get("energy_logs", [])
            org_logs = [l for l in logs if l.get("org_id") == org_id]
            if not org_logs:
                org_logs = get_demo_energy_logs(org_id)
            return org_logs

    # --- Recommendations Operations ---
    def get_recommendations(self, org_id: str) -> List[Dict[str, Any]]:
        if self.use_dynamodb:
            table = self.dynamodb.Table(settings.DYNAMODB_RECOMMENDATIONS_TABLE)
            response = table.scan()
            items = response.get('Items', [])
            return [i for i in items if i.get('org_id') == org_id] or get_demo_recommendations(org_id)
        else:
            db = self._read_local_db()
            recs = db.get("recommendations", [])
            return recs if recs else get_demo_recommendations(org_id)

db_service = DatabaseService()
