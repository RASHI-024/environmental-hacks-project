from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
import datetime
import uuid
from app.services.ai_classifier import ai_classifier
from app.services.s3_service import storage_service
from app.services.db_service import db_service

router = APIRouter(prefix="/api/waste", tags=["Waste Management & AI"])

class ManualWasteEntry(BaseModel):
    category: str
    quantity_kg: float
    date: str
    location: str
    disposal_method: str
    org_id: Optional[str] = "org_college"

@router.post("/analyze-image")
async def analyze_waste_image(
    file: UploadFile = File(...),
    org_id: str = Form("org_college")
):
    try:
        contents = await file.read()
        filename = file.filename or "waste_upload.jpg"
        
        # 1. Upload to S3 / Local Storage
        image_url = storage_service.upload_file(contents, filename, file.content_type or "image/jpeg")
        
        # 2. AI Vision Classifier Prediction
        ai_result = ai_classifier.predict(contents, filename)
        
        # 3. Log analysis result into Database
        waste_record = {
            "id": f"wlog_ai_{uuid.uuid4().hex[:8]}",
            "org_id": org_id,
            "category": ai_result["category"],
            "quantity_kg": round(float(ai_result.get("co2_impact_per_kg", 1.5)) * 1.2, 1),
            "date": datetime.date.today().isoformat(),
            "location": "AI Vision Scan Upload",
            "disposal_method": ai_result["disposal_method"],
            "recyclable": ai_result["recyclable"],
            "image_url": image_url,
            "ai_confidence": ai_result["confidence"],
            "suggested_action": ai_result["suggested_action"],
            "created_at": datetime.datetime.now().isoformat()
        }
        db_service.add_waste_log(waste_record)
        
        return {
            "success": True,
            "image_url": image_url,
            "analysis": ai_result,
            "record": waste_record
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Image analysis error: {str(e)}")

@router.post("/entry")
def create_waste_entry(entry: ManualWasteEntry):
    record = {
        "id": f"wlog_{uuid.uuid4().hex[:8]}",
        "org_id": entry.org_id,
        "category": entry.category,
        "quantity_kg": entry.quantity_kg,
        "date": entry.date,
        "location": entry.location,
        "disposal_method": entry.disposal_method,
        "recyclable": entry.category in ["Plastic", "Paper", "Glass", "Metal", "E-waste"],
        "created_at": datetime.datetime.now().isoformat()
    }
    saved = db_service.add_waste_log(record)
    return {"success": True, "record": saved}

@router.get("/analytics")
def get_waste_analytics(org_id: str = "org_college"):
    logs = db_service.get_waste_logs(org_id)
    org = db_service.get_organization(org_id)
    
    total_waste = sum(l.get("quantity_kg", 0) for l in logs)
    
    # Category aggregation
    category_totals = {
        "Organic": 0.0,
        "Plastic": 0.0,
        "Paper": 0.0,
        "Glass": 0.0,
        "Metal": 0.0,
        "E-waste": 0.0,
        "Other": 0.0
    }
    
    recyclable_kg = 0.0
    
    location_totals: Dict[str, float] = {}
    
    # Daily trend aggregation
    daily_trends: Dict[str, float] = {}
    
    for l in logs:
        cat = l.get("category", "Other")
        qty = l.get("quantity_kg", 0.0)
        loc = l.get("location", "Main Zone")
        dt = l.get("date", str(datetime.date.today()))
        
        if cat in category_totals:
            category_totals[cat] += qty
        else:
            category_totals["Other"] += qty
            
        if l.get("recyclable") or cat in ["Plastic", "Paper", "Glass", "Metal", "E-waste"]:
            recyclable_kg += qty
            
        location_totals[loc] = location_totals.get(loc, 0.0) + qty
        daily_trends[dt] = daily_trends.get(dt, 0.0) + qty

    organic_kg = category_totals["Organic"]
    plastic_kg = category_totals["Plastic"]
    paper_kg = category_totals["Paper"]
    glass_kg = category_totals["Glass"]
    metal_kg = category_totals["Metal"]
    ewaste_kg = category_totals["E-waste"]
    
    # Fill in fallback totals if logs are minimal
    if total_waste == 0:
        total_waste = org.get("total_waste_kg", 12450.0)
        recyclable_kg = org.get("recyclable_kg", 6820.0)
        organic_kg = org.get("organic_kg", 4100.0)
        plastic_kg = org.get("plastic_kg", 1050.0)

    co2_impact = round(recyclable_kg * 2.1 + organic_kg * 1.2, 1)
    estimated_reduction_pct = 24.5
    
    # Sort top problem areas
    top_areas = sorted([{"area": k, "waste_kg": round(v, 1)} for k, v in location_totals.items()], key=lambda x: x["waste_kg"], reverse=True)[:5]
    if not top_areas:
        top_areas = [
            {"area": "Main Cafeteria", "waste_kg": 420.5},
            {"area": "Library Block B", "waste_kg": 310.0},
            {"area": "Engineering Workshop", "waste_kg": 280.2},
            {"area": "Student Hostel Quad", "waste_kg": 215.0}
        ]

    # Format daily chart data
    chart_daily = sorted([{"date": k, "total_kg": round(v, 1)} for k, v in daily_trends.items()], key=lambda x: x["date"])
    
    return {
        "org_id": org_id,
        "org_name": org.get("name"),
        "total_waste_kg": round(total_waste, 1),
        "recyclable_kg": round(recyclable_kg, 1),
        "recyclable_pct": round((recyclable_kg / total_waste * 100) if total_waste > 0 else 55.0, 1),
        "organic_kg": round(organic_kg, 1),
        "plastic_kg": round(plastic_kg, 1),
        "paper_kg": round(paper_kg, 1),
        "glass_kg": round(glass_kg, 1),
        "metal_kg": round(metal_kg, 1),
        "ewaste_kg": round(ewaste_kg, 1),
        "co2_impact_kg": co2_impact,
        "estimated_reduction_pct": estimated_reduction_pct,
        "category_distribution": category_totals,
        "top_problem_areas": top_areas,
        "daily_trends": chart_daily
    }
