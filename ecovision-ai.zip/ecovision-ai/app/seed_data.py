import datetime
from typing import List, Dict, Any

ORGANIZATIONS = [
    {
        "id": "org_college",
        "name": "Green Valley University Campus",
        "type": "College",
        "members_count": 4500,
        "location": "North Campus Sector 4",
        "sustainability_score": 78,
        "energy_spike_pct": 18.5,
        "total_waste_kg": 12450.0,
        "recyclable_kg": 6820.0,
        "organic_kg": 4100.0,
        "plastic_kg": 1050.0,
        "paper_kg": 3200.0,
        "glass_kg": 450.0,
        "metal_kg": 520.0,
        "ewaste_kg": 310.0,
        "co2_saved_kg": 15420.0,
        "trees_equivalent": 734
    },
    {
        "id": "org_hostel",
        "name": "EcoLiving Student Hostel Block A",
        "type": "Hostel",
        "members_count": 650,
        "location": "Hostel Zone East",
        "sustainability_score": 84,
        "energy_spike_pct": 8.2,
        "total_waste_kg": 3480.0,
        "recyclable_kg": 2190.0,
        "organic_kg": 1150.0,
        "plastic_kg": 680.0,
        "paper_kg": 420.0,
        "glass_kg": 210.0,
        "metal_kg": 190.0,
        "ewaste_kg": 830.0,
        "co2_saved_kg": 4890.0,
        "trees_equivalent": 233
    },
    {
        "id": "org_office",
        "name": "NextGen Innovation Tech Park",
        "type": "Office",
        "members_count": 1800,
        "location": "Cyber Heights Tower 2",
        "sustainability_score": 71,
        "energy_spike_pct": 22.4,
        "total_waste_kg": 8920.0,
        "recyclable_kg": 5340.0,
        "organic_kg": 1220.0,
        "plastic_kg": 2100.0,
        "paper_kg": 3900.0,
        "glass_kg": 310.0,
        "metal_kg": 420.0,
        "ewaste_kg": 970.0,
        "co2_saved_kg": 11840.0,
        "trees_equivalent": 564
    },
    {
        "id": "org_community",
        "name": "Harmony Springs Residential Community",
        "type": "Community",
        "members_count": 1200,
        "location": "Greenfield Sector 12",
        "sustainability_score": 89,
        "energy_spike_pct": 4.1,
        "total_waste_kg": 6120.0,
        "recyclable_kg": 4210.0,
        "organic_kg": 3100.0,
        "plastic_kg": 850.0,
        "paper_kg": 920.0,
        "glass_kg": 640.0,
        "metal_kg": 380.0,
        "ewaste_kg": 230.0,
        "co2_saved_kg": 8910.0,
        "trees_equivalent": 424
    }
]

def get_demo_waste_logs(org_id: str = "org_college") -> List[Dict[str, Any]]:
    today = datetime.date.today()
    logs = []
    
    # 14 days of realistic trends
    sample_categories = [
        ("Organic", 45.0, "Cafeteria Main Hall", "Composting Bin"),
        ("Plastic", 18.5, "Student Activity Center", "Recycling Dropoff"),
        ("Paper", 32.0, "Central Library Wing B", "Paper Dumpsters"),
        ("E-waste", 12.0, "Computer Science Lab 3", "E-Waste Locker"),
        ("Glass", 14.2, "Chemistry Lab Annexe", "Glass Bin"),
        ("Metal", 9.8, "Engineering Workshop", "Scrap Scrap Metal"),
        ("Plastic", 24.1, "Hostel Canteen", "Dry Recycling")
    ]
    
    for i in range(14):
        log_date = (today - datetime.timedelta(days=i)).isoformat()
        for cat, base_qty, loc, disp in sample_categories:
            variation = (i * 1.7 + len(cat)) % 7 - 3.5
            qty = max(2.5, round(base_qty + variation, 1))
            logs.append({
                "id": f"wlog_{org_id}_{i}_{cat}",
                "org_id": org_id,
                "category": cat,
                "quantity_kg": qty,
                "date": log_date,
                "location": loc,
                "disposal_method": disp,
                "recyclable": cat in ["Plastic", "Paper", "Glass", "Metal", "E-waste"],
                "created_at": f"{log_date}T10:30:00Z"
            })
    return logs

def get_demo_energy_logs(org_id: str = "org_college") -> List[Dict[str, Any]]:
    today = datetime.date.today()
    energy_logs = []
    
    buildings = ["Main Academic Block", "Science Complex", "Hostel Block A", "Admin Tower"]
    for i in range(12):
        log_date = (today - datetime.timedelta(days=i*2)).isoformat()
        for bld in buildings:
            kwh = 1450.0 + (i * 35) + (len(bld) * 20)
            water_l = 8500.0 + (i * 120)
            operating_hrs = 14.0 if i % 2 == 0 else 16.5
            
            # Anomaly spike flag for demonstration
            is_anomaly = (i == 1 and bld == "Main Academic Block") or (i == 3 and bld == "Science Complex")
            
            energy_logs.append({
                "id": f"elog_{org_id}_{i}_{bld.replace(' ', '_')}",
                "org_id": org_id,
                "building": bld,
                "date": log_date,
                "electricity_kwh": kwh,
                "water_liters": water_l,
                "operating_hours": operating_hrs,
                "is_anomaly": is_anomaly,
                "spike_percentage": 18.5 if is_anomaly else 2.1,
                "cost_usd": round(kwh * 0.14 + water_l * 0.003, 2)
            })
    return energy_logs

def get_demo_recommendations(org_id: str = "org_college") -> List[Dict[str, Any]]:
    return [
        {
            "id": "rec_01",
            "priority": "Critical",
            "category": "Energy",
            "title": "HVAC & Lighting Running Post 7:00 PM in Science Complex",
            "problem": "Electricity consumption spiked by 18.5% in Science Complex during non-peak operating hours.",
            "why_it_matters": "Adds an estimated $1,420/month in wasted electricity and emits 4.2 tons of unnecessary CO₂.",
            "recommended_action": "Install automated smart motion sensors and programmable timer relays for lighting and climate controls.",
            "expected_benefit": "Reduces total energy consumption by 15-22% ($1,200+/mo saved).",
            "impact_score": 95,
            "status": "Active"
        },
        {
            "id": "rec_02",
            "priority": "High",
            "category": "Waste",
            "title": "Single-Use Plastic Bottle Surge at Cafeteria",
            "problem": "Plastic waste surged by 22% in the Main Cafeteria over the past 3 weeks.",
            "why_it_matters": "Contributes to landfill overflow and non-recyclable contamination rates.",
            "recommended_action": "Deploy smart water refill stations and introduce a zero-plastic reusable bottle incentive program.",
            "expected_benefit": "Diverts approximately 450 kg of plastic waste per month.",
            "impact_score": 88,
            "status": "Active"
        },
        {
            "id": "rec_03",
            "priority": "Medium",
            "category": "Composting",
            "title": "Organic Food Scrap Segregation in Hostel Mess",
            "problem": "Unsegregated organic food waste is currently mixed into general refuse bins.",
            "why_it_matters": "Mixed food waste generates anaerobic methane gas in landfills instead of nutrient-rich fertilizer.",
            "recommended_action": "Implement dual-stream wet waste sorting tables and set up an on-site bio-digester/vermicompost unit.",
            "expected_benefit": "Produces 300+ kg of organic compost monthly for campus gardens.",
            "impact_score": 76,
            "status": "In Progress"
        },
        {
            "id": "rec_04",
            "priority": "Low",
            "category": "Paper",
            "title": "Digitize Administrative Exam & Approval Workflows",
            "problem": "Paper consumption in Admin Tower remains at 3,200 kg annually.",
            "why_it_matters": "Consumes 54 trees worth of paper pulp and requires physical storage.",
            "recommended_action": "Transition to digital sign-offs, e-exam portals, and double-sided printing mandates.",
            "expected_benefit": "Saves $2,400 in paper procurement and cuts paper waste by 60%.",
            "impact_score": 62,
            "status": "Active"
        }
    ]
