"""
AWS Lambda Serverless Handler for EcoVision AI.
Wraps the FastAPI application ASGI instance to run seamlessly on AWS Lambda behind Amazon API Gateway.
"""
try:
    from mangum import Mangum
    from app.main import app
    handler = Mangum(app)
except ImportError:
    def handler(event, context):
        return {
            "statusCode": 200,
            "body": "EcoVision AI Serverless Lambda Ready. Install mangum for full ASGI proxy."
        }
