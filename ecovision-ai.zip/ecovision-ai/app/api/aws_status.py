from fastapi import APIRouter
from app.config import settings
from app.services.db_service import db_service
from app.services.s3_service import storage_service

router = APIRouter(prefix="/api/aws", tags=["AWS Infrastructure Status"])

@router.get("/status")
def get_aws_status():
    has_creds = settings.has_aws_credentials
    using_dynamo = db_service.use_dynamodb
    using_s3 = storage_service.use_s3
    
    return {
        "aws_mode": "Live AWS Cloud Connected" if (using_dynamo or using_s3) else "Local Simulation & Fallback Mode",
        "aws_region": settings.AWS_REGION,
        "services": {
            "amazon_s3": {
                "service": "Amazon S3 (Simple Storage Service)",
                "bucket": settings.S3_BUCKET_NAME,
                "status": "Active / Connected" if using_s3 else "Local Disk Fallback (/static/uploads/)",
                "purpose": "Stores high-resolution waste inspection images & AI scan outputs."
            },
            "amazon_dynamodb": {
                "service": "Amazon DynamoDB (NoSQL Database)",
                "tables": [
                    settings.DYNAMODB_USERS_TABLE,
                    settings.DYNAMODB_WASTE_TABLE,
                    settings.DYNAMODB_ENERGY_TABLE,
                    settings.DYNAMODB_RECOMMENDATIONS_TABLE
                ],
                "status": "Active / Connected" if using_dynamo else "Local File Store Fallback (data/ecovision_db.json)",
                "purpose": "Stores user profiles, real-time waste logs, energy logs, and AI recommendations."
            },
            "aws_lambda": {
                "service": "AWS Lambda (Serverless Backend)",
                "status": "Ready for Deployment (Serverless SAM template active)",
                "handler": "app.lambda_handler.handler",
                "purpose": "Executes serverless image processing & REST endpoints on demand."
            },
            "amazon_api_gateway": {
                "service": "Amazon API Gateway",
                "status": "Configured (CloudFront CORS ready)",
                "purpose": "Routes HTTP REST traffic from React frontend to serverless Lambda functions."
            }
        },
        "credentials_configured": has_creds,
        "instructions": "To activate live AWS cloud mode, set AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, and AWS_REGION in .env."
    }
