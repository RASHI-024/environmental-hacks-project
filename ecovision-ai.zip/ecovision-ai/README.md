# EcoVision AI – Smart Waste & Energy Optimization Platform

> **Hackathon Track**: Waste & Energy Track  
> **Tagline**: *"See Waste. Understand Impact. Build a Greener Future."*  
> **Target Audience**: Colleges, Student Hostels, Tech Park Offices, and Residential Communities.

---

## 🌿 Problem Statement & Solution

### The Environmental Problem
Institutions (colleges, hostels, corporate parks, residential complexes) generate tons of unsegregated waste and waste up to 25% of their utility budget on off-peak energy usage. Lack of real-time visibility into waste stream composition and utility spikes prevents facility managers from making data-backed sustainability decisions.

### The EcoVision AI Solution
**EcoVision AI** provides an all-in-one AI-powered sustainability management platform that:
1. **Classifies Waste using AI Computer Vision**: Instantly identifies waste categories (Organic, Plastic, Paper, Glass, Metal, E-waste, Other) from inspection images, providing confidence scores, bin routing instructions, and environmental impact data.
2. **Detects Energy & Resource Anomalies**: Identifies sudden consumption spikes (e.g. `Electricity usage increased by 18.5% compared with last month`) and prescribes automated lighting/HVAC optimization protocols.
3. **Calculates Quantified Ecological Impact**: Estimates landfill diversion rates, CO₂ offset equivalents, trees saved equivalent, and water saved.
4. **Generates Prioritized Smart Recommendations**: Produces actionable cards categorized by urgency (Critical, High, Medium, Low) with problem statements, why it matters, recommended actions, and expected ROI.
5. **Provides Institutional Sustainability Scores (0–100)**: Evaluates performance across 5 core metrics with actionable improvement roadmaps.

---

## 🌟 Key Features Breakdown

| Feature | Description |
| :--- | :--- |
| **1. Modern Landing Page** | Environmental-themed UI with problem/solution breakdown, live stats ticker, and AWS badges. |
| **2. Multi-Organization Auth** | Login & register with tailored profile support for **Colleges**, **Hostels**, **Offices**, and **Communities**. |
| **3. Main Dashboard** | Live metric cards for total waste, recyclable %, CO₂ offset, energy wastage alerts, and sustainability score dial. |
| **4. AI Waste Classifier** | Drag-and-drop image upload with computer vision breakdown, confidence meter, bin routing, and suggested actions. |
| **5. Waste Log Data Entry** | Form interface for manual waste logging (quantity kg, zone, date, disposal method). |
| **6. Waste Analytics & Charts** | Interactive visual charts showing daily/monthly trends, category distribution, recyclable vs landfill ratios, and top waste zones. |
| **7. Energy & Resource Insights** | Utility consumption audit (kWh, water L, operating hours) with anomaly detection (+18% spike alerts) and energy-saving protocols. |
| **8. AI Recommendations Engine** | Prioritized recommendation cards (Critical, High, Medium, Low) detailing problem, rationale, action, and expected benefit. |
| **9. Impact Calculator** | Real-time calculation of landfill diverted, CO₂ reduction, trees saved, and water saved using EPA WARM standards. |
| **10. Sustainability Scorecard** | 0-100 gauge score evaluated across 5 key pillars with tailored improvement tips. |
| **11. Admin & Org Overview** | Cross-department benchmark comparison matrix and AWS Infrastructure status inspector. |
| **12. AWS Integration** | Native cloud connection to Amazon S3, DynamoDB, AWS Lambda, API Gateway, and local fallback mode. |

---

## ☁️ AWS Cloud Integration

EcoVision AI is designed cloud-native and connects to AWS services:

* **Amazon S3 (`ecovision-waste-images`)**: Stores uploaded waste inspection photos and returns pre-signed asset URLs.
* **Amazon DynamoDB (NoSQL Data Store)**: Stores user accounts (`EcoVision_Users`), waste entries (`EcoVision_WasteLogs`), utility metrics (`EcoVision_EnergyLogs`), and recommendations (`EcoVision_Recommendations`).
* **AWS Lambda & Amazon API Gateway**: Executes serverless API endpoints on demand via `mangum` ASGI wrapper.
* **Dual-Mode Fallback System**: If AWS credentials (`AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`) are present in `.env`, the app operates live on AWS. If omitted, it automatically operates in local file storage mode, ensuring 100% functionality out of the box during judging presentations!

---

## ⚙️ How the AI Computer Vision Component Works

1. **Input**: User uploads a waste photo (or selects a quick demo preset: Plastic bottle, Apple core, Cardboard, Circuit board).
2. **Feature Extraction**: The `EcoVisionAIClassifier` engine analyzes RGB color histograms, brightness distributions, saturation variance, and contrast texture patterns.
3. **Classification**: Categorizes items into **7 categories**:
   - `Organic` (Compostable wet waste, food scraps)
   - `Plastic` (PET bottles, wrappers, containers)
   - `Paper` (Cardboard boxes, office documents)
   - `Glass` (Jars, bottles)
   - `Metal` (Aluminum cans, scrap)
   - `E-waste` (Circuit boards, cables, electronics)
   - `Other` (Non-recyclable composite refuse)
4. **Actionable Output**: Calculates confidence score, bin color routing, recyclable status, CO₂ impact per kg, and suggested remediation steps.

---

## 🚀 Quick Start & Setup Instructions

### Prerequisites
- Python 3.10+ installed
- Web browser (Chrome, Firefox, Edge)

### 1. Installation
Clone or navigate to the project directory:
```bash
cd ecovision-ai
```

Install Python dependencies:
```bash
python -m pip install -r requirements.txt
```

### 2. Configure Environment (Optional AWS Mode)
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
*(Leave default or blank to run in local demo mode with zero setup overhead)*

### 3. Run Application
Launch the local web server:
```bash
python run.py
```

Open your browser at:  
👉 **`http://localhost:8000`**

---

## 📂 Project Structure

```
ecovision-ai/
├── app/
│   ├── main.py                     # FastAPI application entrypoint & static mounting
│   ├── config.py                   # Environment settings & AWS configurations
│   ├── seed_data.py                # Multi-organization realistic demo data generator
│   ├── lambda_handler.py           # AWS Lambda serverless handler
│   ├── api/
│   │   ├── auth.py                 # User auth & profile endpoints
│   │   ├── waste.py                # AI waste image classification & waste entry endpoints
│   │   ├── energy.py               # Energy usage input & anomaly detection endpoints
│   │   ├── recommendations.py      # Prioritized AI recommendations engine
│   │   ├── impact.py               # Environmental impact calculation & score endpoints
│   │   └── aws_status.py           # AWS service health check & connectivity status
│   └── services/
│       ├── ai_classifier.py        # Computer Vision AI classification engine
│       ├── db_service.py           # DynamoDB / Local JSON storage manager
│       └── s3_service.py           # Amazon S3 / Local upload manager
├── static/
│   ├── index.html                  # Responsive HTML5 SPA shell
│   ├── css/
│   │   └── styles.css              # Custom Tailwind & glassmorphic styling
│   └── js/
│       └── app.js                  # React SPA Single Page Application script
├── docs/
│   ├── ARCHITECTURE.md             # AWS Cloud System Architecture documentation
│   └── API_DOCS.md                 # OpenAPI endpoint documentation
├── template.yaml                   # AWS SAM CloudFormation template
├── .env.example                    # Sample environment variable template
├── requirements.txt                # Python package dependencies
├── run.py                          # Application launcher script
└── README.md                       # Comprehensive hackathon presentation guide
```

---

## 🏆 Hackathon Presentation Notes for Judges

* **Interactive Multi-Organization Switcher**: In the top navbar, judges can instantly toggle between **Green Valley University Campus**, **EcoLiving Student Hostel**, **NextGen Innovation Tech Park**, and **Harmony Springs Community** to see how metrics and AI recommendations adapt dynamically.
* **1-Click AI Presets**: In the **AI Scanner** tab, click any demo preset button (*Plastic Bottle, Apple Core, Cardboard Box, Circuit Board*) to test AI computer vision classification instantly!
* **AWS Integration Status**: Check the **AWS Admin** tab to inspect live status for Amazon S3, DynamoDB, AWS Lambda, and API Gateway.
