import sys
import uvicorn
from app.config import settings

if __name__ == "__main__":
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    print("=" * 60)
    print(f"Launching {settings.APP_NAME} v{settings.APP_VERSION}")
    print(f"Server running at: http://127.0.0.1:8000")
    print(f"AWS Cloud Credentials Status: {'CONNECTED' if settings.has_aws_credentials else 'LOCAL FALLBACK MODE'}")
    print("=" * 60)
    
    uvicorn.run("app.main:app", host="127.0.0.1", port=8000, reload=True)
