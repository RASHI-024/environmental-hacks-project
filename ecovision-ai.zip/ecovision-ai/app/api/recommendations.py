from fastapi import APIRouter
from typing import List, Dict, Any
from app.services.db_service import db_service

router = APIRouter(prefix="/api/recommendations", tags=["AI Recommendations"])

@router.get("/")
def get_recommendations(org_id: str = "org_college"):
    recs = db_service.get_recommendations(org_id)
    
    # Priority sorting helper
    priority_order = {"Critical": 1, "High": 2, "Medium": 3, "Low": 4}
    sorted_recs = sorted(recs, key=lambda x: priority_order.get(x.get("priority", "Low"), 5))
    
    return {
        "org_id": org_id,
        "total_count": len(sorted_recs),
        "critical_count": sum(1 for r in sorted_recs if r.get("priority") == "Critical"),
        "high_count": sum(1 for r in sorted_recs if r.get("priority") == "High"),
        "medium_count": sum(1 for r in sorted_recs if r.get("priority") == "Medium"),
        "low_count": sum(1 for r in sorted_recs if r.get("priority") == "Low"),
        "recommendations": sorted_recs
    }
