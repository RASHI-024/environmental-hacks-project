import os

class Settings:
    APP_NAME: str = "EcoVision AI"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = True
    
    # AWS Configurations
    AWS_REGION: str = os.getenv("AWS_REGION", "us-east-1")
    AWS_ACCESS_KEY_ID: str = os.getenv("AWS_ACCESS_KEY_ID", "")
    AWS_SECRET_ACCESS_KEY: str = os.getenv("AWS_SECRET_ACCESS_KEY", "")
    S3_BUCKET_NAME: str = os.getenv("S3_BUCKET_NAME", "ecovision-waste-images")
    
    # DynamoDB Tables
    DYNAMODB_USERS_TABLE: str = os.getenv("DYNAMODB_USERS_TABLE", "EcoVision_Users")
    DYNAMODB_WASTE_TABLE: str = os.getenv("DYNAMODB_WASTE_TABLE", "EcoVision_WasteLogs")
    DYNAMODB_ENERGY_TABLE: str = os.getenv("DYNAMODB_ENERGY_TABLE", "EcoVision_EnergyLogs")
    DYNAMODB_RECOMMENDATIONS_TABLE: str = os.getenv("DYNAMODB_RECOMMENDATIONS_TABLE", "EcoVision_Recommendations")
    
    # Storage settings
    BASE_DIR: str = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    LOCAL_STORAGE_DIR: str = os.path.join(BASE_DIR, "static", "uploads")
    LOCAL_DATA_DIR: str = os.path.join(BASE_DIR, "data")
    
    @property
    def has_aws_credentials(self) -> bool:
        return bool(self.AWS_ACCESS_KEY_ID and self.AWS_SECRET_ACCESS_KEY)

settings = Settings()
