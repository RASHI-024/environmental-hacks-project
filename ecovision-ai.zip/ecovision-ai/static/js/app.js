const { useState, useEffect, useRef } = React;

// --- Main EcoVision App Component ---
function EcoVisionApp() {
  const [activeTab, setActiveTab] = useState('landing'); // landing, dashboard, analyzer, entry, analytics, energy, recommendations, impact, score, admin
  const [selectedOrgId, setSelectedOrgId] = useState('org_college');
  const [user, setUser] = useState({
    email: 'sustainability@campus.edu',
    full_name: 'Dr. Aris Vance',
    organization_id: 'org_college',
    organization_name: 'Green Valley University Campus',
    organization_type: 'College',
    role: 'Sustainability Director'
  });
  
  const [organizations, setOrganizations] = useState([]);
  const [wasteAnalytics, setWasteAnalytics] = useState(null);
  const [energyInsights, setEnergyInsights] = useState(null);
  const [recommendations, setRecommendations] = useState([]);
  const [impactData, setImpactData] = useState(null);
  const [awsStatus, setAwsStatus] = useState(null);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  // Fetch data on org change
  useEffect(() => {
    fetchInitialData(selectedOrgId);
  }, [selectedOrgId]);

  const fetchInitialData = async (orgId) => {
    setLoading(true);
    try {
      const [orgsRes, wasteRes, energyRes, recsRes, impactRes, awsRes] = await Promise.all([
        fetch('/api/auth/organizations').then(r => r.json()),
        fetch(`/api/waste/analytics?org_id=${orgId}`).then(r => r.json()),
        fetch(`/api/energy/insights?org_id=${orgId}`).then(r => r.json()),
        fetch(`/api/recommendations/?org_id=${orgId}`).then(r => r.json()),
        fetch(`/api/impact/calculator?org_id=${orgId}`).then(r => r.json()),
        fetch('/api/aws/status').then(r => r.json())
      ]);

      setOrganizations(orgsRes);
      setWasteAnalytics(wasteRes);
      setEnergyInsights(energyRes);
      setRecommendations(recsRes.recommendations || []);
      setImpactData(impactRes);
      setAwsStatus(awsRes);
    } catch (err) {
      console.error("Error loading EcoVision data:", err);
    } finally {
      setLoading(false);
    }
  };

  const currentOrg = organizations.find(o => o.id === selectedOrgId) || {
    name: "Green Valley University Campus",
    type: "College"
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#08100e] text-emerald-50 selection:bg-emerald-500 selection:text-black">
      {/* Top Navbar */}
      <Navbar 
        activeTab={activeTab} 
        setActiveTab={setActiveTab}
        selectedOrgId={selectedOrgId}
        setSelectedOrgId={setSelectedOrgId}
        organizations={organizations}
        user={user}
        setIsAuthOpen={setIsAuthOpen}
        awsStatus={awsStatus}
      />

      {/* Main Content View */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'landing' && <LandingPage setActiveTab={setActiveTab} awsStatus={awsStatus} />}
        {activeTab === 'dashboard' && <MainDashboard analytics={wasteAnalytics} energy={energyInsights} impact={impactData} setActiveTab={setActiveTab} currentOrg={currentOrg} />}
        {activeTab === 'analyzer' && <AIWasteAnalyzer orgId={selectedOrgId} onAnalysisComplete={() => fetchInitialData(selectedOrgId)} />}
        {activeTab === 'entry' && <WasteDataEntry orgId={selectedOrgId} onEntryAdded={() => fetchInitialData(selectedOrgId)} setActiveTab={setActiveTab} />}
        {activeTab === 'analytics' && <WasteAnalytics analytics={wasteAnalytics} />}
        {activeTab === 'energy' && <EnergyInsights energy={energyInsights} orgId={selectedOrgId} onEnergyLogged={() => fetchInitialData(selectedOrgId)} />}
        {activeTab === 'recommendations' && <AIRecommendations recommendations={recommendations} />}
        {activeTab === 'impact' && <EnvironmentalImpact impact={impactData} />}
        {activeTab === 'score' && <SustainabilityScorecard impact={impactData} />}
        {activeTab === 'admin' && <AdminDashboard organizations={organizations} awsStatus={awsStatus} currentOrgId={selectedOrgId} setSelectedOrgId={setSelectedOrgId} />}
      </main>

      {/* Auth Modal */}
      {isAuthOpen && (
        <AuthModal 
          user={user} 
          setUser={setUser} 
          onClose={() => setIsAuthOpen(false)} 
          organizations={organizations}
          setSelectedOrgId={setSelectedOrgId}
        />
      )}

      {/* Footer */}
      <footer className="border-t border-emerald-900/40 py-8 bg-[#040908] text-center text-xs text-emerald-400/60 mt-12">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
            <span className="font-semibold text-emerald-300">EcoVision AI</span>
            <span>— Waste & Energy Optimization Platform</span>
          </div>
          <div>
            Powered by <strong className="text-emerald-300">Amazon S3</strong>, <strong className="text-emerald-300">DynamoDB</strong> & <strong className="text-emerald-300">AWS Lambda</strong>
          </div>
          <div>© 2026 Environmental Hackathon Submission</div>
        </div>
      </footer>
    </div>
  );
}

// --- Navbar Component ---
function Navbar({ activeTab, setActiveTab, selectedOrgId, setSelectedOrgId, organizations, user, setIsAuthOpen, awsStatus }) {
  return (
    <header className="sticky top-0 z-40 bg-[#06120e]/90 backdrop-blur-md border-b border-emerald-900/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setActiveTab('landing')}>
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center shadow-lg shadow-emerald-900/50">
            <svg className="w-6 h-6 text-black font-bold" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 3v18m9-9H3m14-6l3 6-3 6M7 6L4 12l3 6"></path>
            </svg>
          </div>
          <div>
            <h1 className="font-extrabold text-lg text-emerald-300 tracking-tight leading-none">EcoVision <span className="text-emerald-500">AI</span></h1>
            <p className="text-[10px] text-emerald-400/70 font-medium tracking-wide uppercase">Waste & Energy Platform</p>
          </div>
        </div>

        {/* Demo Organization Selector */}
        <div className="hidden lg:flex items-center bg-emerald-950/80 border border-emerald-800/50 rounded-lg px-3 py-1.5 space-x-2">
          <span className="text-xs text-emerald-400/80 font-medium">Org View:</span>
          <select 
            value={selectedOrgId} 
            onChange={(e) => setSelectedOrgId(e.target.value)}
            className="bg-transparent text-xs font-semibold text-emerald-200 outline-none cursor-pointer"
          >
            {organizations.map(o => (
              <option key={o.id} value={o.id} className="bg-emerald-950 text-emerald-200">
                {o.name} ({o.type})
              </option>
            ))}
          </select>
        </div>

        {/* Navigation Links */}
        <nav className="hidden md:flex items-center space-x-1 text-xs font-semibold">
          {[
            { id: 'landing', label: 'Home' },
            { id: 'dashboard', label: 'Dashboard' },
            { id: 'analyzer', label: 'AI Scanner', badge: 'AI' },
            { id: 'entry', label: 'Log Waste' },
            { id: 'analytics', label: 'Analytics' },
            { id: 'energy', label: 'Energy' },
            { id: 'recommendations', label: 'Smart Recs' },
            { id: 'impact', label: 'Impact' },
            { id: 'score', label: 'Scorecard' },
            { id: 'admin', label: 'AWS Admin' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-3 py-2 rounded-lg transition-all flex items-center space-x-1 ${
                activeTab === tab.id 
                  ? 'bg-emerald-500 text-black font-bold shadow-md shadow-emerald-500/20' 
                  : 'text-emerald-300/80 hover:text-emerald-200 hover:bg-emerald-900/40'
              }`}
            >
              <span>{tab.label}</span>
              {tab.badge && (
                <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-bold ${activeTab === tab.id ? 'bg-black text-emerald-400' : 'bg-emerald-500/20 text-emerald-400'}`}>
                  {tab.badge}
                </span>
              )}
            </button>
          ))}
        </nav>

        {/* AWS Status & Profile CTA */}
        <div className="flex items-center space-x-3">
          <div className="hidden sm:flex items-center space-x-1.5 bg-emerald-900/30 border border-emerald-700/40 rounded-full px-2.5 py-1 text-[11px] text-emerald-300">
            <span className={`w-2 h-2 rounded-full ${awsStatus?.credentials_configured ? 'bg-emerald-400 animate-ping' : 'bg-teal-400'}`}></span>
            <span>{awsStatus?.credentials_configured ? 'AWS DynamoDB/S3 Live' : 'AWS Cloud Simulation'}</span>
          </div>

          <button 
            onClick={() => setIsAuthOpen(true)}
            className="flex items-center space-x-2 bg-gradient-to-r from-emerald-600 to-teal-600 text-black font-bold text-xs px-3.5 py-2 rounded-lg hover:brightness-110 transition shadow-lg shadow-emerald-900/40"
          >
            <div className="w-5 h-5 rounded-full bg-black/30 flex items-center justify-center text-[10px] text-emerald-300 font-extrabold">
              {user.full_name[0]}
            </div>
            <span className="hidden sm:inline">{user.full_name.split(' ')[0]}</span>
          </button>
        </div>
      </div>
    </header>
  );
}

// --- Landing Page Component ---
function LandingPage({ setActiveTab, awsStatus }) {
  return (
    <div className="space-y-16 py-8">
      {/* Hero Section */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-b from-emerald-950/80 via-emerald-900/30 to-transparent border border-emerald-800/40 p-8 sm:p-14 text-center">
        <div className="inline-flex items-center space-x-2 bg-emerald-500/10 border border-emerald-500/30 rounded-full px-4 py-1.5 mb-6">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
          <span className="text-xs font-semibold text-emerald-300 tracking-wide uppercase">Waste & Energy Optimization Hackathon Track</span>
        </div>

        <h1 className="text-4xl sm:text-6xl font-black text-white tracking-tight max-w-4xl mx-auto leading-tight">
          See Waste. Understand Impact. <br />
          <span className="gradient-text-emerald">Build a Greener Future.</span>
        </h1>

        <p className="mt-6 text-base sm:text-lg text-emerald-200/80 max-w-2xl mx-auto font-normal">
          EcoVision AI helps Colleges, Hostels, Offices, and Communities identify waste bottlenecks, detect energy anomalies (+18% spike alerts), classify waste using computer vision, and deliver actionable sustainability recommendations.
        </p>

        <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
          <button 
            onClick={() => setActiveTab('dashboard')} 
            className="w-full sm:w-auto px-8 py-4 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 text-black font-extrabold text-base hover:shadow-xl hover:shadow-emerald-500/30 hover:scale-[1.02] transition-all"
          >
            Launch Main Dashboard →
          </button>
          <button 
            onClick={() => setActiveTab('analyzer')} 
            className="w-full sm:w-auto px-8 py-4 rounded-xl bg-emerald-950/80 border border-emerald-700/50 text-emerald-300 font-bold text-base hover:bg-emerald-900/50 transition-all flex items-center justify-center space-x-2"
          >
            <span>Try AI Waste Scanner</span>
            <span className="bg-emerald-500/20 text-emerald-400 text-xs px-2 py-0.5 rounded-full">Vision v2.4</span>
          </button>
        </div>

        {/* Live Metrics Ticker */}
        <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto pt-8 border-t border-emerald-900/40 text-left">
          <div className="p-4 bg-emerald-950/40 rounded-xl border border-emerald-800/30">
            <div className="text-2xl font-black text-emerald-400">12,450 kg</div>
            <div className="text-xs text-emerald-300/70 mt-1 font-medium">Total Waste Tracked</div>
          </div>
          <div className="p-4 bg-emerald-950/40 rounded-xl border border-emerald-800/30">
            <div className="text-2xl font-black text-teal-400">54.7%</div>
            <div className="text-xs text-emerald-300/70 mt-1 font-medium">Recyclable Material Recovery</div>
          </div>
          <div className="p-4 bg-emerald-950/40 rounded-xl border border-emerald-800/30">
            <div className="text-2xl font-black text-amber-400">18.5%</div>
            <div className="text-xs text-emerald-300/70 mt-1 font-medium">Energy Anomaly Spike Fixed</div>
          </div>
          <div className="p-4 bg-emerald-950/40 rounded-xl border border-emerald-800/30">
            <div className="text-2xl font-black text-emerald-300">15.4 Tons</div>
            <div className="text-xs text-emerald-300/70 mt-1 font-medium">CO₂ Offset Equivalent</div>
          </div>
        </div>
      </div>

      {/* Feature Grid */}
      <div className="space-y-6">
        <div className="text-center max-w-2xl mx-auto">
          <h2 className="text-3xl font-extrabold text-white">End-to-End Smart Sustainability Suite</h2>
          <p className="text-sm text-emerald-300/70 mt-2">Designed specifically for real-world enterprise & campus environmental deployment.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="glass-panel p-6 glass-panel-hover space-y-4">
            <div className="w-12 h-12 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-xl">
              📷
            </div>
            <h3 className="text-xl font-bold text-white">AI Vision Classifier</h3>
            <p className="text-xs text-emerald-200/70 leading-relaxed">
              Upload waste images for instant 7-category breakdown (Organic, Plastic, Paper, Glass, Metal, E-waste, Other) with confidence scores and bin segregation instructions.
            </p>
          </div>

          <div className="glass-panel p-6 glass-panel-hover space-y-4">
            <div className="w-12 h-12 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-xl">
              ⚡
            </div>
            <h3 className="text-xl font-bold text-white">Energy Anomaly Insights</h3>
            <p className="text-xs text-emerald-200/70 leading-relaxed">
              Detect sudden energy spikes (+18% alerts), audit operating hours, and receive actionable tips like automated lighting shutdowns post 7 PM.
            </p>
          </div>

          <div className="glass-panel p-6 glass-panel-hover space-y-4">
            <div className="w-12 h-12 rounded-xl bg-teal-500/20 text-teal-400 flex items-center justify-center font-bold text-xl">
              📊
            </div>
            <h3 className="text-xl font-bold text-white">Impact & Scorecard (0-100)</h3>
            <p className="text-xs text-emerald-200/70 leading-relaxed">
              Calculate landfill diversion rates, trees saved equivalent, and benchmark performance across 5 key sustainability pillars.
            </p>
          </div>
        </div>
      </div>

      {/* AWS Cloud Architecture Section */}
      <div className="glass-panel p-8 sm:p-10 border border-emerald-700/50 space-y-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2 text-left">
            <div className="inline-flex items-center space-x-2 text-xs font-bold text-emerald-400 uppercase tracking-wider">
              <span>Cloud Native Architecture</span>
            </div>
            <h3 className="text-2xl font-black text-white">AWS Integration Showcase</h3>
            <p className="text-xs text-emerald-200/70 max-w-xl">
              Built on scalable AWS serverless infrastructure for high availability, zero server overhead, and fast processing.
            </p>
          </div>

          <div className="flex flex-wrap gap-3">
            {['Amazon S3', 'Amazon DynamoDB', 'AWS Lambda', 'Amazon API Gateway'].map(aws => (
              <span key={aws} className="px-3.5 py-1.5 rounded-lg bg-emerald-950 border border-emerald-700/50 text-emerald-300 text-xs font-semibold flex items-center space-x-2">
                <span className="w-2 h-2 rounded-full bg-amber-400"></span>
                <span>{aws}</span>
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// --- Main Dashboard Component ---
function MainDashboard({ analytics, energy, impact, setActiveTab, currentOrg }) {
  if (!analytics || !impact) return <div className="text-center py-12 text-emerald-400">Loading Dashboard Metrics...</div>;

  return (
    <div className="space-y-8 py-4">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 p-6 glass-panel border-emerald-800/50">
        <div>
          <div className="flex items-center space-x-2 text-xs font-bold text-emerald-400 uppercase tracking-wider">
            <span>{currentOrg.type} Sustainability Dashboard</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-white mt-1">{currentOrg.name}</h2>
          <p className="text-xs text-emerald-300/70 mt-1">Real-time waste segregation & resource efficiency metrics</p>
        </div>

        <div className="flex items-center space-x-3">
          <button 
            onClick={() => setActiveTab('analyzer')} 
            className="px-4 py-2.5 rounded-lg bg-emerald-500 text-black font-bold text-xs hover:bg-emerald-400 transition shadow-lg shadow-emerald-500/20"
          >
            + AI Scan Image
          </button>
          <button 
            onClick={() => setActiveTab('entry')} 
            className="px-4 py-2.5 rounded-lg bg-emerald-950 border border-emerald-700 text-emerald-300 font-semibold text-xs hover:bg-emerald-900 transition"
          >
            + Log Waste Data
          </button>
        </div>
      </div>

      {/* Energy Spike Warning Alert Banner */}
      {energy?.energy_spike_detected && (
        <div className="p-4 rounded-xl bg-amber-950/70 border border-amber-500/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 glow-amber">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-lg">
              ⚠️
            </div>
            <div>
              <h4 className="font-bold text-amber-300 text-sm">Energy Wastage Indicator Triggered</h4>
              <p className="text-xs text-amber-200/80">{energy.spike_message}</p>
            </div>
          </div>
          <button 
            onClick={() => setActiveTab('energy')} 
            className="px-3.5 py-1.5 rounded-lg bg-amber-500 text-black font-bold text-xs hover:bg-amber-400 transition whitespace-nowrap"
          >
            View Anomaly Insights →
          </button>
        </div>
      )}

      {/* Metric Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <div className="glass-panel p-5 space-y-2 border-emerald-800/40">
          <div className="flex items-center justify-between text-xs text-emerald-400/80 font-semibold">
            <span>Total Waste Recorded</span>
            <span className="text-emerald-400">📦 Total</span>
          </div>
          <div className="text-3xl font-black text-white">{analytics.total_waste_kg.toLocaleString()} <span className="text-sm font-normal text-emerald-400">kg</span></div>
          <div className="text-[11px] text-emerald-300/70 font-medium">Estimated Reduction: <strong className="text-emerald-400">-{analytics.estimated_reduction_pct}%</strong></div>
        </div>

        <div className="glass-panel p-5 space-y-2 border-emerald-800/40">
          <div className="flex items-center justify-between text-xs text-emerald-400/80 font-semibold">
            <span>Recyclable Material</span>
            <span className="text-teal-400">♻️ {analytics.recyclable_pct}%</span>
          </div>
          <div className="text-3xl font-black text-teal-300">{analytics.recyclable_kg.toLocaleString()} <span className="text-sm font-normal text-teal-400">kg</span></div>
          <div className="text-[11px] text-emerald-300/70 font-medium">Diverted from Landfill</div>
        </div>

        <div className="glass-panel p-5 space-y-2 border-emerald-800/40">
          <div className="flex items-center justify-between text-xs text-emerald-400/80 font-semibold">
            <span>CO₂ Impact Offset</span>
            <span className="text-emerald-400">🌱 Saved</span>
          </div>
          <div className="text-3xl font-black text-emerald-400">{analytics.co2_impact_kg.toLocaleString()} <span className="text-sm font-normal text-emerald-400">kg CO₂</span></div>
          <div className="text-[11px] text-emerald-300/70 font-medium">Equivalent to ~{impact.impact_estimates?.trees_saved_equivalent} Trees planted</div>
        </div>

        <div className="glass-panel p-5 space-y-2 border-emerald-800/40 flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-emerald-400/80 font-semibold">
            <span>Sustainability Score</span>
            <span className="text-amber-400 font-bold">{impact.score_rating}</span>
          </div>
          <div className="flex items-baseline space-x-2">
            <span className="text-4xl font-black text-emerald-300">{impact.sustainability_score}</span>
            <span className="text-sm font-bold text-emerald-500">/ 100</span>
          </div>
          <div className="w-full bg-emerald-950 rounded-full h-2 overflow-hidden">
            <div className="bg-gradient-to-r from-emerald-500 to-teal-400 h-full rounded-full" style={{ width: `${impact.sustainability_score}%` }}></div>
          </div>
        </div>
      </div>

      {/* Category Breakdown & Top Problem Zones */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Category Pill Cards */}
        <div className="lg:col-span-2 glass-panel p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-bold text-white">Waste Category Distribution</h3>
            <button onClick={() => setActiveTab('analytics')} className="text-xs font-semibold text-emerald-400 hover:underline">Full Analytics →</button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { name: "Organic", kg: analytics.organic_kg, color: "emerald", icon: "🍏" },
              { name: "Plastic", kg: analytics.plastic_kg, color: "amber", icon: "🥤" },
              { name: "Paper", kg: analytics.paper_kg, color: "blue", icon: "📄" },
              { name: "E-waste", kg: analytics.ewaste_kg, color: "purple", icon: "💻" },
              { name: "Glass", kg: analytics.glass_kg, color: "teal", icon: "🍾" },
              { name: "Metal", kg: analytics.metal_kg, color: "zinc", icon: "🥫" }
            ].map(c => (
              <div key={c.name} className="p-3 bg-emerald-950/60 rounded-xl border border-emerald-800/40 text-left">
                <div className="text-base">{c.icon} <span className="text-xs font-bold text-emerald-200">{c.name}</span></div>
                <div className="text-lg font-extrabold text-white mt-1">{c.kg} kg</div>
              </div>
            ))}
          </div>
        </div>

        {/* Top Problem Areas */}
        <div className="glass-panel p-6 space-y-4">
          <h3 className="text-lg font-bold text-white">Top Waste Producing Zones</h3>
          <div className="space-y-3">
            {analytics.top_problem_areas.map((area, idx) => (
              <div key={area.area} className="flex items-center justify-between p-2.5 rounded-lg bg-emerald-950/40 border border-emerald-900/40">
                <div className="flex items-center space-x-2.5">
                  <span className="w-5 h-5 rounded-full bg-emerald-800/60 text-emerald-300 font-bold text-xs flex items-center justify-center">{idx + 1}</span>
                  <span className="text-xs font-semibold text-emerald-200">{area.area}</span>
                </div>
                <span className="text-xs font-bold text-emerald-400">{area.waste_kg} kg</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// --- AI Waste Analyzer Component ---
function AIWasteAnalyzer({ orgId, onAnalysisComplete }) {
  const [selectedImage, setSelectedImage] = useState(null);
  const [previewUrl, setPreviewUrl] = useState('');
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState(null);

  // Sample presets for quick demo judging
  const presets = [
    { label: "Plastic Bottle", file: "plastic_bottle.jpg", category: "Plastic", color: "amber" },
    { label: "Apple Core / Food", file: "apple_core.jpg", category: "Organic", color: "emerald" },
    { label: "Cardboard Box", file: "cardboard_box.jpg", category: "Paper", color: "blue" },
    { label: "Circuit Board", file: "circuit_board.jpg", category: "E-waste", color: "purple" }
  ];

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setSelectedImage(file);
      setPreviewUrl(URL.createObjectURL(file));
      setResult(null);
    }
  };

  const handlePresetSelect = (preset) => {
    // Generate mock byte payload simulation for preset demo
    const blob = new Blob(["demo_waste_image_data"], { type: "image/jpeg" });
    const dummyFile = new File([blob], preset.file, { type: "image/jpeg" });
    setSelectedImage(dummyFile);
    setPreviewUrl(`https://images.unsplash.com/photo-1595278069441-2cf29f8005a4?auto=format&fit=crop&w=400&q=80`);
    setResult(null);
  };

  const runAIAnalysis = async () => {
    if (!selectedImage) return;
    setAnalyzing(true);
    setResult(null);

    const formData = new FormData();
    formData.append("file", selectedImage);
    formData.append("org_id", orgId);

    try {
      const res = await fetch("/api/waste/analyze-image", {
        method: "POST",
        body: formData
      });
      const data = await res.json();
      if (data.success) {
        setResult(data.analysis);
        if (onAnalysisComplete) onAnalysisComplete();
      }
    } catch (err) {
      console.error("AI Analysis error:", err);
    } finally {
      setAnalyzing(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 py-4">
      <div className="text-center space-y-2">
        <div className="inline-flex items-center space-x-2 bg-emerald-500/10 border border-emerald-500/30 rounded-full px-3 py-1 text-xs text-emerald-400 font-bold">
          <span>AI Vision Engine v2.4</span>
        </div>
        <h2 className="text-3xl font-black text-white">Smart AI Waste Classifier</h2>
        <p className="text-xs text-emerald-300/70">Upload waste inspection photos for immediate classification, bin routing, and impact analysis.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Upload & Preview Box */}
        <div className="glass-panel p-6 space-y-4 border-emerald-800/50">
          <h3 className="text-base font-bold text-white">1. Select or Upload Image</h3>
          
          {/* Preset Buttons */}
          <div className="space-y-1">
            <span className="text-[11px] text-emerald-400/80 font-semibold">Quick Demo Presets:</span>
            <div className="flex flex-wrap gap-2">
              {presets.map(p => (
                <button 
                  key={p.label}
                  onClick={() => handlePresetSelect(p)}
                  className="px-2.5 py-1 rounded-md bg-emerald-950 border border-emerald-800/60 text-emerald-300 text-xs hover:border-emerald-500 transition font-medium"
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          {/* Upload Input Dropzone */}
          <label className="block w-full border-2 border-dashed border-emerald-700/60 rounded-xl p-6 text-center cursor-pointer hover:border-emerald-500 hover:bg-emerald-950/30 transition">
            <input type="file" accept="image/*" onChange={handleFileChange} className="hidden" />
            {previewUrl ? (
              <img src={previewUrl} alt="Waste Preview" className="max-h-56 mx-auto rounded-lg object-contain shadow-md" />
            ) : (
              <div className="space-y-2 py-4">
                <div className="text-4xl">📸</div>
                <div className="text-xs font-bold text-emerald-300">Click or Drag Image Here</div>
                <div className="text-[10px] text-emerald-400/60">Supports JPG, PNG, WEBP files</div>
              </div>
            )}
          </label>

          <button 
            onClick={runAIAnalysis}
            disabled={!selectedImage || analyzing}
            className="w-full py-3.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 text-black font-extrabold text-sm disabled:opacity-50 hover:brightness-110 transition shadow-lg shadow-emerald-500/20"
          >
            {analyzing ? "Analyzing Image with Computer Vision..." : "Run AI Classification →"}
          </button>
        </div>

        {/* Results Card */}
        <div className="glass-panel p-6 border-emerald-800/50 flex flex-col justify-between">
          <h3 className="text-base font-bold text-white mb-4">2. AI Classification Results</h3>

          {analyzing && (
            <div className="my-auto text-center py-12 space-y-3">
              <div className="w-12 h-12 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto"></div>
              <p className="text-xs text-emerald-300 font-semibold">Analyzing RGB spectra, color histograms, and texture features...</p>
            </div>
          )}

          {!analyzing && !result && (
            <div className="my-auto text-center py-12 text-xs text-emerald-400/60">
              Upload an image and click "Run AI Classification" to see results.
            </div>
          )}

          {!analyzing && result && (
            <div className="space-y-5">
              {/* Category Badge & Confidence */}
              <div className="flex items-center justify-between p-4 rounded-xl bg-emerald-950/80 border border-emerald-700/50">
                <div>
                  <div className="text-[10px] text-emerald-400/70 uppercase tracking-wide font-bold">Detected Waste Category</div>
                  <div className="text-2xl font-black text-white">{result.category}</div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] text-emerald-400/70 font-semibold">AI Confidence</div>
                  <div className="text-lg font-black text-emerald-400">{(result.confidence * 100).toFixed(0)}%</div>
                </div>
              </div>

              {/* Status Badges */}
              <div className="flex space-x-2">
                <span className={`px-3 py-1 rounded-full text-xs font-bold ${result.recyclable ? 'bg-teal-500/20 text-teal-300 border border-teal-500/40' : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'}`}>
                  {result.recyclable ? "✓ Recyclable Material" : "✕ Non-Recyclable"}
                </span>
                {result.compostable && (
                  <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                    🌱 Compostable
                  </span>
                )}
              </div>

              {/* Disposal & Action */}
              <div className="space-y-3 text-xs">
                <div className="p-3 bg-emerald-950/40 rounded-lg border border-emerald-900/50">
                  <strong className="text-emerald-400 block mb-0.5">Recommended Disposal Method:</strong>
                  <span className="text-emerald-200">{result.disposal_method}</span>
                </div>

                <div className="p-3 bg-emerald-950/40 rounded-lg border border-emerald-900/50">
                  <strong className="text-teal-400 block mb-0.5">Suggested Action:</strong>
                  <span className="text-emerald-200">{result.suggested_action}</span>
                </div>

                <div className="p-3 bg-emerald-950/40 rounded-lg border border-emerald-900/50">
                  <strong className="text-amber-400 block mb-0.5">Environmental Impact:</strong>
                  <span className="text-emerald-200">{result.environmental_impact}</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// --- Waste Data Entry Component ---
function WasteDataEntry({ orgId, onEntryAdded, setActiveTab }) {
  const [category, setCategory] = useState('Plastic');
  const [quantityKg, setQuantityKg] = useState('15.5');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [location, setLocation] = useState('Cafeteria Main Hall');
  const [disposalMethod, setDisposalMethod] = useState('Recycling Dropoff');
  const [submitting, setSubmitting] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setSuccessMsg('');

    try {
      const res = await fetch("/api/waste/entry", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          category,
          quantity_kg: parseFloat(quantityKg),
          date,
          location,
          disposal_method: disposalMethod,
          org_id: orgId
        })
      });
      const data = await res.json();
      if (data.success) {
        setSuccessMsg("Waste log entry saved successfully!");
        if (onEntryAdded) onEntryAdded();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-xl mx-auto py-6">
      <div className="glass-panel p-8 space-y-6 border-emerald-800/50">
        <div>
          <h2 className="text-2xl font-black text-white">Manual Waste Data Entry</h2>
          <p className="text-xs text-emerald-300/70 mt-1">Record waste log data manually for institutional audit tracking.</p>
        </div>

        {successMsg && (
          <div className="p-3 rounded-lg bg-emerald-500/20 border border-emerald-500/50 text-emerald-300 text-xs font-bold">
            ✓ {successMsg}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block text-emerald-300 font-semibold mb-1">Waste Category</label>
            <select 
              value={category} 
              onChange={e => setCategory(e.target.value)}
              className="w-full bg-emerald-950 border border-emerald-800 rounded-lg p-2.5 text-emerald-200 outline-none focus:border-emerald-500"
            >
              {['Organic', 'Plastic', 'Paper', 'Glass', 'Metal', 'E-waste', 'Other'].map(c => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-emerald-300 font-semibold mb-1">Quantity (kg)</label>
            <input 
              type="number" 
              step="0.1" 
              value={quantityKg} 
              onChange={e => setQuantityKg(e.target.value)}
              className="w-full bg-emerald-950 border border-emerald-800 rounded-lg p-2.5 text-emerald-200 outline-none focus:border-emerald-500"
              required 
            />
          </div>

          <div>
            <label className="block text-emerald-300 font-semibold mb-1">Log Date</label>
            <input 
              type="date" 
              value={date} 
              onChange={e => setDate(e.target.value)}
              className="w-full bg-emerald-950 border border-emerald-800 rounded-lg p-2.5 text-emerald-200 outline-none focus:border-emerald-500"
              required 
            />
          </div>

          <div>
            <label className="block text-emerald-300 font-semibold mb-1">Location / Zone</label>
            <input 
              type="text" 
              value={location} 
              onChange={e => setLocation(e.target.value)}
              className="w-full bg-emerald-950 border border-emerald-800 rounded-lg p-2.5 text-emerald-200 outline-none focus:border-emerald-500"
              required 
            />
          </div>

          <div>
            <label className="block text-emerald-300 font-semibold mb-1">Disposal Method</label>
            <input 
              type="text" 
              value={disposalMethod} 
              onChange={e => setDisposalMethod(e.target.value)}
              className="w-full bg-emerald-950 border border-emerald-800 rounded-lg p-2.5 text-emerald-200 outline-none focus:border-emerald-500"
              required 
            />
          </div>

          <button 
            type="submit" 
            disabled={submitting}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 text-black font-extrabold hover:brightness-110 transition shadow-md shadow-emerald-500/20"
          >
            {submitting ? "Saving Log..." : "Save Waste Log Entry →"}
          </button>
        </form>
      </div>
    </div>
  );
}

// --- Waste Analytics Component ---
function WasteAnalytics({ analytics }) {
  if (!analytics) return <div className="text-center py-12 text-emerald-400">Loading Analytics...</div>;

  return (
    <div className="space-y-8 py-4">
      <div>
        <h2 className="text-3xl font-black text-white">Waste Analytics & Trends</h2>
        <p className="text-xs text-emerald-300/70 mt-1">Interactive category distribution, daily trends, and zone analysis.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Category Breakdown Table */}
        <div className="glass-panel p-6 space-y-4">
          <h3 className="text-base font-bold text-white">Category Breakdown (kg)</h3>
          <div className="space-y-3 text-xs">
            {Object.entries(analytics.category_distribution).map(([cat, kg]) => (
              <div key={cat} className="space-y-1">
                <div className="flex justify-between font-semibold">
                  <span className="text-emerald-200">{cat}</span>
                  <span className="text-emerald-400 font-bold">{kg} kg</span>
                </div>
                <div className="w-full bg-emerald-950 rounded-full h-2">
                  <div className="bg-emerald-500 h-full rounded-full" style={{ width: `${Math.min(100, (kg / analytics.total_waste_kg) * 100)}%` }}></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recyclable vs Non-Recyclable Ratio */}
        <div className="glass-panel p-6 space-y-4 flex flex-col justify-between">
          <h3 className="text-base font-bold text-white">Recyclable vs Landfill Ratio</h3>
          <div className="p-6 bg-emerald-950/60 rounded-xl text-center space-y-4">
            <div className="text-5xl font-black text-teal-300">{analytics.recyclable_pct}%</div>
            <div className="text-xs text-emerald-300 font-medium">Of total waste diverted to recycling streams</div>
            <div className="flex justify-center space-x-6 text-xs">
              <div>
                <span className="block text-emerald-400 font-bold">{analytics.recyclable_kg} kg</span>
                <span className="text-emerald-400/70 text-[10px]">Recyclable</span>
              </div>
              <div>
                <span className="block text-rose-400 font-bold">{(analytics.total_waste_kg - analytics.recyclable_kg).toFixed(1)} kg</span>
                <span className="text-emerald-400/70 text-[10px]">Landfill Refuse</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// --- Energy Insights Component ---
function EnergyInsights({ energy, orgId, onEnergyLogged }) {
  const [building, setBuilding] = useState('Science Complex');
  const [electricityKwh, setElectricityKwh] = useState('1850.0');
  const [waterLiters, setWaterLiters] = useState('9200.0');
  const [operatingHours, setOperatingHours] = useState('16.0');
  const [submitting, setSubmitting] = useState(false);

  if (!energy) return <div className="text-center py-12 text-emerald-400">Loading Energy Insights...</div>;

  const handleLogEnergy = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await fetch("/api/energy/entry", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          building,
          electricity_kwh: parseFloat(electricityKwh),
          water_liters: parseFloat(waterLiters),
          operating_hours: parseFloat(operatingHours),
          org_id: orgId
        })
      });
      if (onEnergyLogged) onEnergyLogged();
    } catch (err) {
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-8 py-4">
      <div>
        <h2 className="text-3xl font-black text-white">Energy & Resource Insights</h2>
        <p className="text-xs text-emerald-300/70 mt-1">Audit utility consumption and fix energy wastage anomalies.</p>
      </div>

      {/* Energy Spike Warning Banner */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-amber-950/80 to-amber-900/30 border border-amber-500/50 glow-amber flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="inline-flex items-center space-x-1.5 px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-bold uppercase">
            <span>Critical Anomaly Detected</span>
          </div>
          <h3 className="text-xl font-bold text-amber-200">{energy.spike_message}</h3>
          <p className="text-xs text-amber-300/80">Off-peak HVAC and computer lab lighting running post 7 PM detected in Science Complex.</p>
        </div>
        <div className="text-right whitespace-nowrap">
          <div className="text-3xl font-black text-amber-400">+{energy.spike_percentage}%</div>
          <div className="text-[10px] text-amber-300/70">Unnecessary Spike</div>
        </div>
      </div>

      {/* Input Form & Actionable Suggestions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Entry Form */}
        <div className="glass-panel p-6 space-y-4">
          <h3 className="text-base font-bold text-white">Log Energy Consumption</h3>
          <form onSubmit={handleLogEnergy} className="space-y-3 text-xs">
            <div>
              <label className="block text-emerald-300 mb-1 font-medium">Building / Zone</label>
              <input type="text" value={building} onChange={e => setBuilding(e.target.value)} className="w-full bg-emerald-950 border border-emerald-800 rounded-lg p-2 text-emerald-200" required />
            </div>
            <div>
              <label className="block text-emerald-300 mb-1 font-medium">Electricity (kWh)</label>
              <input type="number" step="10" value={electricityKwh} onChange={e => setElectricityKwh(e.target.value)} className="w-full bg-emerald-950 border border-emerald-800 rounded-lg p-2 text-emerald-200" required />
            </div>
            <div>
              <label className="block text-emerald-300 mb-1 font-medium">Water Usage (Liters)</label>
              <input type="number" step="100" value={waterLiters} onChange={e => setWaterLiters(e.target.value)} className="w-full bg-emerald-950 border border-emerald-800 rounded-lg p-2 text-emerald-200" required />
            </div>
            <div>
              <label className="block text-emerald-300 mb-1 font-medium">Operating Hours / Day</label>
              <input type="number" step="0.5" value={operatingHours} onChange={e => setOperatingHours(e.target.value)} className="w-full bg-emerald-950 border border-emerald-800 rounded-lg p-2 text-emerald-200" required />
            </div>
            <button type="submit" disabled={submitting} className="w-full py-2.5 rounded-lg bg-emerald-500 text-black font-bold hover:bg-emerald-400 transition">
              {submitting ? "Processing..." : "Log Energy Metric"}
            </button>
          </form>
        </div>

        {/* Suggestions List */}
        <div className="lg:col-span-2 space-y-4">
          <h3 className="text-base font-bold text-white">Actionable Optimization Recommendations</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {energy.actionable_suggestions.map(s => (
              <div key={s.title} className="glass-panel p-5 space-y-2 border-emerald-800/40">
                <div className="text-[10px] text-emerald-400 font-bold uppercase tracking-wider">{s.category}</div>
                <h4 className="text-sm font-bold text-white">{s.title}</h4>
                <p className="text-xs text-emerald-200/70">{s.description}</p>
                <div className="pt-2 border-t border-emerald-900/40 flex justify-between text-xs font-semibold">
                  <span className="text-teal-400">Save {s.estimated_kwh_saved || s.estimated_water_saved}</span>
                  <span className="text-emerald-400">{s.cost_reduction_monthly}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// --- AI Recommendations Component ---
function AIRecommendations({ recommendations }) {
  return (
    <div className="space-y-6 py-4">
      <div>
        <h2 className="text-3xl font-black text-white">Smart Prioritized Recommendations</h2>
        <p className="text-xs text-emerald-300/70 mt-1">AI-generated sustainability roadmap categorized by impact priority.</p>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {recommendations.map(rec => (
          <div key={rec.id} className="glass-panel p-6 space-y-4 border-emerald-800/40">
            <div className="flex items-center justify-between">
              <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                rec.priority === 'Critical' ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40' :
                rec.priority === 'High' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40' :
                'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
              }`}>
                {rec.priority} Priority
              </span>
              <span className="text-xs text-emerald-400/80 font-bold">Impact Score: {rec.impact_score}/100</span>
            </div>

            <h3 className="text-xl font-bold text-white">{rec.title}</h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="p-3 bg-emerald-950/50 rounded-lg border border-emerald-900/40">
                <strong className="text-amber-400 block mb-1">Problem:</strong>
                <p className="text-emerald-200/80">{rec.problem}</p>
              </div>

              <div className="p-3 bg-emerald-950/50 rounded-lg border border-emerald-900/40">
                <strong className="text-rose-400 block mb-1">Why It Matters:</strong>
                <p className="text-emerald-200/80">{rec.why_it_matters}</p>
              </div>

              <div className="p-3 bg-emerald-950/50 rounded-lg border border-emerald-900/40">
                <strong className="text-teal-400 block mb-1">Recommended Action:</strong>
                <p className="text-emerald-200/80">{rec.recommended_action}</p>
              </div>

              <div className="p-3 bg-emerald-950/50 rounded-lg border border-emerald-900/40">
                <strong className="text-emerald-400 block mb-1">Expected Benefit:</strong>
                <p className="text-emerald-200/80">{rec.expected_benefit}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// --- Environmental Impact Component ---
function EnvironmentalImpact({ impact }) {
  if (!impact) return <div className="text-center py-12 text-emerald-400">Loading Environmental Impact...</div>;

  const estimates = impact.impact_estimates || {};

  return (
    <div className="space-y-8 py-4">
      <div>
        <h2 className="text-3xl font-black text-white">Environmental Impact Calculator</h2>
        <p className="text-xs text-emerald-300/70 mt-1">Quantified ecological benefits and carbon footprint offset metrics.</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <div className="glass-panel p-6 text-center space-y-2">
          <div className="text-4xl">⛰️</div>
          <div className="text-2xl font-black text-white">{estimates.waste_diverted_landfill_kg?.toLocaleString()} kg</div>
          <div className="text-xs font-bold text-emerald-400">Waste Diverted from Landfill</div>
          <div className="text-[10px] text-emerald-300/60">({estimates.waste_diverted_landfill_pct}% total recovery rate)</div>
        </div>

        <div className="glass-panel p-6 text-center space-y-2">
          <div className="text-4xl">🌱</div>
          <div className="text-2xl font-black text-emerald-400">{estimates.co2_reduction_kg?.toLocaleString()} kg</div>
          <div className="text-xs font-bold text-emerald-300">Approximate CO₂ Reduction</div>
          <div className="text-[10px] text-emerald-300/60">Avoided greenhouse emissions</div>
        </div>

        <div className="glass-panel p-6 text-center space-y-2">
          <div className="text-4xl">🌳</div>
          <div className="text-2xl font-black text-teal-300">{estimates.trees_saved_equivalent}</div>
          <div className="text-xs font-bold text-teal-400">Trees Saved Equivalent</div>
          <div className="text-[10px] text-emerald-300/60">Annual carbon absorption basis</div>
        </div>

        <div className="glass-panel p-6 text-center space-y-2">
          <div className="text-4xl">💧</div>
          <div className="text-2xl font-black text-amber-300">{estimates.water_saved_liters?.toLocaleString()} L</div>
          <div className="text-xs font-bold text-amber-400">Estimated Water Conserved</div>
          <div className="text-[10px] text-emerald-300/60">Recycling pulp & process savings</div>
        </div>
      </div>

      <div className="p-4 rounded-xl bg-emerald-950/40 border border-emerald-800/40 text-xs text-emerald-300/70 text-center">
        * Note: All values are estimates calculated using standard EPA WARM v15 & GHG Conversion Protocols.
      </div>
    </div>
  );
}

// --- Sustainability Scorecard Component ---
function SustainabilityScorecard({ impact }) {
  if (!impact) return <div className="text-center py-12 text-emerald-400">Loading Scorecard...</div>;

  return (
    <div className="max-w-3xl mx-auto space-y-8 py-4">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-black text-white">Sustainability Scorecard (0–100)</h2>
        <p className="text-xs text-emerald-300/70">Institutional environmental performance score breakdown.</p>
      </div>

      <div className="glass-panel p-8 text-center space-y-4 border-emerald-800/50">
        <div className="text-6xl font-black text-emerald-400">{impact.sustainability_score} <span className="text-xl font-normal text-emerald-500">/ 100</span></div>
        <div className="inline-block px-4 py-1.5 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-500/40">
          {impact.score_rating}
        </div>

        <div className="pt-6 grid grid-cols-1 gap-3 text-left">
          {Object.entries(impact.score_breakdown || {}).map(([key, item]) => (
            <div key={key} className="p-3 bg-emerald-950/60 rounded-xl border border-emerald-900/40 space-y-1 text-xs">
              <div className="flex justify-between font-bold">
                <span className="text-emerald-200">{item.label}</span>
                <span className="text-emerald-400">{item.score} / 100</span>
              </div>
              <div className="w-full bg-emerald-950 rounded-full h-1.5">
                <div className="bg-emerald-500 h-full rounded-full" style={{ width: `${item.score}%` }}></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// --- Admin Dashboard Component ---
function AdminDashboard({ organizations, awsStatus, currentOrgId, setSelectedOrgId }) {
  return (
    <div className="space-y-8 py-4">
      <div>
        <h2 className="text-3xl font-black text-white">Admin & AWS Cloud Infrastructure</h2>
        <p className="text-xs text-emerald-300/70 mt-1">Cross-organization monitoring and live AWS service health inspector.</p>
      </div>

      {/* Organization Comparison Matrix */}
      <div className="glass-panel p-6 space-y-4">
        <h3 className="text-base font-bold text-white">Multi-Organization Benchmark Overview</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-emerald-800/60 text-emerald-400 uppercase font-semibold">
                <th className="p-2">Organization</th>
                <th className="p-2">Type</th>
                <th className="p-2">Members</th>
                <th className="p-2">Total Waste</th>
                <th className="p-2">Recyclable</th>
                <th className="p-2">Score</th>
                <th className="p-2">Action</th>
              </tr>
            </thead>
            <tbody>
              {organizations.map(o => (
                <tr key={o.id} className="border-b border-emerald-900/40 hover:bg-emerald-950/40">
                  <td className="p-2 font-bold text-emerald-100">{o.name}</td>
                  <td className="p-2 text-emerald-300">{o.type}</td>
                  <td className="p-2 text-emerald-300">{o.members_count}</td>
                  <td className="p-2 text-emerald-300">{o.total_waste_kg} kg</td>
                  <td className="p-2 text-teal-400 font-semibold">{o.recyclable_kg} kg</td>
                  <td className="p-2 text-emerald-400 font-bold">{o.sustainability_score}/100</td>
                  <td className="p-2">
                    <button onClick={() => setSelectedOrgId(o.id)} className="px-2.5 py-1 rounded bg-emerald-500 text-black font-bold text-[10px]">
                      View Dashboard
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* AWS Integration Inspector */}
      {awsStatus && (
        <div className="glass-panel p-6 space-y-4 border-emerald-800/50">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white">AWS Service Integration Inspector</h3>
            <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold">
              {awsStatus.aws_mode}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            {Object.entries(awsStatus.services || {}).map(([key, svc]) => (
              <div key={key} className="p-4 bg-emerald-950/60 rounded-xl border border-emerald-800/40 space-y-1">
                <div className="font-bold text-emerald-300">{svc.service}</div>
                <div className="text-emerald-400 font-semibold">Status: {svc.status}</div>
                <div className="text-emerald-200/70 text-[11px]">{svc.purpose}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// --- Auth Modal Component ---
function AuthModal({ user, setUser, onClose, organizations, setSelectedOrgId }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [orgType, setOrgType] = useState('College');

  const handleLogin = (e) => {
    e.preventDefault();
    const demoUser = {
      email,
      full_name: email.split('@')[0].toUpperCase() || "DEMO USER",
      organization_type: orgType,
      role: "Sustainability Officer"
    };
    setUser(demoUser);
    const matchedOrg = organizations.find(o => o.type === orgType);
    if (matchedOrg) setSelectedOrgId(matchedOrg.id);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="glass-panel p-8 max-w-md w-full space-y-6 border-emerald-700/60">
        <div className="flex justify-between items-center">
          <h3 className="text-xl font-black text-white">User Authentication</h3>
          <button onClick={onClose} className="text-emerald-400 font-bold hover:text-white">✕</button>
        </div>

        <form onSubmit={handleLogin} className="space-y-4 text-xs">
          <div>
            <label className="block text-emerald-300 font-semibold mb-1">Email Address</label>
            <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="user@campus.edu" className="w-full bg-emerald-950 border border-emerald-800 rounded-lg p-2.5 text-emerald-200 outline-none" required />
          </div>

          <div>
            <label className="block text-emerald-300 font-semibold mb-1">Password</label>
            <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" className="w-full bg-emerald-950 border border-emerald-800 rounded-lg p-2.5 text-emerald-200 outline-none" required />
          </div>

          <div>
            <label className="block text-emerald-300 font-semibold mb-1">Organization Type</label>
            <select value={orgType} onChange={e => setOrgType(e.target.value)} className="w-full bg-emerald-950 border border-emerald-800 rounded-lg p-2.5 text-emerald-200 outline-none">
              <option value="College">College / University</option>
              <option value="Hostel">Student Hostel</option>
              <option value="Office">Tech Park / Office</option>
              <option value="Community">Residential Community</option>
            </select>
          </div>

          <button type="submit" className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 text-black font-extrabold hover:brightness-110 transition shadow-lg shadow-emerald-500/20">
            Sign In / Register →
          </button>
        </form>
      </div>
    </div>
  );
}

// Render React App into DOM
ReactDOM.createRoot(document.getElementById('root')).render(<EcoVisionApp />);
