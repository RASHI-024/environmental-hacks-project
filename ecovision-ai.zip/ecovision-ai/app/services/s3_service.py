import os
import uuid
import logging
from app.config import settings

logger = logging.getLogger("ecovision.s3")

class StorageService:
    def __init__(self):
        self.use_s3 = False
        self.s3_client = None
        self._init_s3()

    def _init_s3(self):
        if settings.has_aws_credentials:
            try:
                import boto3
                self.s3_client = boto3.client(
                    's3',
                    region_name=settings.AWS_REGION,
                    aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
                    aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY
                )
                self.use_s3 = True
                logger.info("Amazon S3 client initialized.")
            except Exception as e:
                logger.warning(f"S3 init failed: {e}. Using local storage fallback.")
                self.use_s3 = False
        else:
            os.makedirs(settings.LOCAL_STORAGE_DIR, exist_ok=True)

    def upload_file(self, file_bytes: bytes, filename: str, content_type: str = "image/jpeg") -> str:
        """Upload file to S3 or local directory and return viewable URL."""
        ext = os.path.splitext(filename)[1] or ".jpg"
        unique_name = f"{uuid.uuid4().hex}{ext}"
        
        if self.use_s3:
            try:
                self.s3_client.put_object(
                    Bucket=settings.S3_BUCKET_NAME,
                    Key=f"waste_images/{unique_name}",
                    Body=file_bytes,
                    ContentType=content_type
                )
                url = f"https://{settings.S3_BUCKET_NAME}.s3.{settings.AWS_REGION}.amazonaws.com/waste_images/{unique_name}"
                return url
            except Exception as e:
                logger.error(f"S3 upload error: {e}. Falling back to local file write.")
        
        # Local upload fallback
        os.makedirs(settings.LOCAL_STORAGE_DIR, exist_ok=True)
        local_path = os.path.join(settings.LOCAL_STORAGE_DIR, unique_name)
        with open(local_path, "wb") as f:
            f.write(file_bytes)
        return f"/static/uploads/{unique_name}"

storage_service = StorageService()
